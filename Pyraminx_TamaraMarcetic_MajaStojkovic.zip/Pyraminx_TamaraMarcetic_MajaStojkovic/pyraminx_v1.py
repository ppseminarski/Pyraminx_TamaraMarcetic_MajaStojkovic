#! /usr/bin/python


from Tkinter import*
import sys

def center(toplevel):
    toplevel.update_idletasks()
    w = toplevel.winfo_screenwidth()
    h = toplevel.winfo_screenheight()
    size = tuple(int(_) for _ in toplevel.geometry().split('+')[0].split('x'))
    x = w/2 - size[0]/2
    y = h/2 - size[1]/2
    toplevel.geometry("%dx%d+%d+%d" % (size + (x, y)))

# osnovne funkcije

def R(A,C,D):
  pom = A[3]
  A[3] = D[3]
  D[3] = C[6]
  C[6] = pom
  pom = A[6]
  A[6] = D[6]
  D[6] = C[1]
  C[1] = pom
  pom = A[7]
  A[7] = D[7]
  D[7] = C[5]
  C[5] = pom
  pom = A[8]
  A[8] = D[8]
  D[8] = C[4]
  C[4] = pom

def L(B,C,D):
  pom = B[1]
  B[1] = C[6]
  C[6] = D[1]
  D[1] = pom
  pom = B[4]
  B[4] = C[8]
  C[8] = D[4]
  D[4] = pom
  pom = B[5]
  B[5] = C[7]
  C[7] = D[5]
  D[5] = pom
  pom = B[6]
  B[6] = C[3]
  C[3] = D[6]
  D[6] = pom

def U(A,B,D):
  pom = A[1]
  A[1] = B[6]
  B[6] = D[3]
  D[3] = pom
  pom = A[4]
  A[4] = B[8]
  B[8] = D[0]
  D[0] = pom
  pom = A[5]
  A[5] = B[7]
  B[7] = D[2]
  D[2] = pom
  pom = A[6]
  A[6] = B[3]
  B[3] = D[1]
  D[1] = pom

def fB(A,B,C):
  pom = A[0]
  A[0] = C[0]
  C[0] = B[0]
  B[0] = pom
  pom = A[1]
  A[1] = C[1]
  C[1] = B[1]
  B[1] = pom
  pom = A[2]
  A[2] = C[2]
  C[2] = B[2]
  B[2] = pom
  pom = A[3]
  A[3] = C[3]
  C[3] = B[3]
  B[3] = pom

def CABC(A,B,C,D):
  for i in range (9):
    pom = A[i]
    A[i] = C[i]
    C[i] = B[i]
    B[i] = pom
  pom = D[0]
  D[0] = D[8]
  D[8] = D[4]
  D[4] = pom
  pom = D[1]
  D[1] = D[3]
  D[3] = D[6]
  D[6] = pom
  pom = D[2]
  D[2] = D[7]
  D[7] = D[5]
  D[5] = pom

def BACB(A,B,C,D):
  for i in range(9):
    pom = A[i]
    A[i] = B[i]
    B[i] = C[i]
    C[i] = pom
  pom = D[0]
  D[0] = D[4]
  D[4] = D[8]
  D[8] = pom
  pom = D[1]
  D[1] = D[6]
  D[6] = D[3]
  D[3] = pom
  pom = D[2]
  D[2] = D[5]
  D[5] = D[7]
  D[7] = pom

def BCDB(A,B,C,D):
  pom = B[0]
  B[0] = D[0]
  D[0] = C[4]
  C[4] = pom
  pom = B[1]
  B[1] = D[1]
  D[1] = C[6]
  C[6] = pom
  pom = B[2]
  B[2] = D[2]
  D[2] = C[5]
  C[5] = pom
  pom = B[3]
  B[3] = D[3]
  D[3] = C[1]
  C[1] = pom
  pom = B[4]
  B[4] = D[4]
  D[4] = C[8]
  C[8] = pom
  pom = B[5]
  B[5] = D[5]
  D[5] = C[7]
  C[7] = pom
  pom = B[6]
  B[6] = D[6]
  D[6] = C[3]
  C[3] = pom
  pom = B[7]
  B[7] = D[7]
  D[7] = C[2]
  C[2] = pom
  pom = B[8]
  B[8] = D[8]
  D[8] = C[0]
  C[0] = pom
  pom = A[0]
  A[0] = A[4]
  A[4] = A[8]
  A[8] = pom
  pom = A[1]
  A[1] = A[6]
  A[6] = A[3]
  A[3] = pom
  pom = A[2]
  A[2] = A[5]
  A[5] = A[7]
  A[7] = pom

def ADBA(A,B,C,D):
  pom = A[0]
  A[0] = B[4]
  B[4] = D[8]
  D[8] = pom
  pom = A[1]
  A[1] = B[6]
  B[6] = D[3]
  D[3] = pom
  pom = A[2]
  A[2] = B[5]
  B[5] = D[7]
  D[7] = pom
  pom = A[3]
  A[3] = B[1]
  B[1] = D[6]
  D[6] = pom
  pom = A[4]
  A[4] = B[8]
  B[8] = D[0]
  D[0] = pom
  pom = A[5]
  A[5] = B[7]
  B[7] = D[2]
  D[2] = pom
  pom = A[6]
  A[6] = B[3]
  B[3] = D[1]
  D[1] = pom
  pom = A[7]
  A[7] = B[2]
  B[2] = D[5]
  D[5] = pom
  pom = A[8]
  A[8] = B[0]
  B[0] = D[4]
  D[4] = pom
  pom = C[0]
  C[0] = C[8]
  C[8] = C[4]
  C[4] = pom
  pom = C[1]
  C[1] = C[3]
  C[3] = C[6]
  C[6] = pom
  pom = C[2]
  C[2] = C[7]
  C[7] = C[5]
  C[5] = pom

def ABDA(A,B,C,D):
  pom = A[0]
  A[0] = D[8]
  D[8] = B[4]
  B[4] = pom
  pom = A[1]
  A[1] = D[3]
  D[3] = B[6]
  B[6] = pom
  pom = A[2]
  A[2] = D[7]
  D[7] = B[5]
  B[5] = pom
  pom = A[3]
  A[3] = D[6]
  D[6] = B[1]
  B[1] = pom
  pom = A[4]
  A[4] = D[0]
  D[0] = B[8]
  B[8] = pom
  pom = A[5]
  A[5] = D[2]
  D[2] = B[7]
  B[7] = pom
  pom = A[6]
  A[6] = D[1]
  D[1] = B[3]
  B[3] = pom
  pom = A[7]
  A[7] = D[5]
  D[5] = B[2]
  B[2] = pom
  pom = A[8]
  A[8] = D[4]
  D[4] = B[0]
  B[0] = pom
  pom = C[0]
  C[0] = C[4]
  C[4] = C[8]
  C[8] = pom
  pom = C[1]
  C[1] = C[6]
  C[6] = C[3]
  C[3] = pom
  pom = C[2]
  C[2] = C[5]
  C[5] = C[7]
  C[7] = pom

def drugi_korak(A,B,C,D):
  if A[3] == A[2] and C[1] == B[2]:
    R(A,C,D)
    L(B,C,D)
    R(A,C,D)
    R(A,C,D)
    L(B,C,D)
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"R L R' L B L' B'")
    dodeli_boje(A,B,C,D)
    #print "R L R' L B L' B'"
  elif A[6] == A[2] and D[3] == B[2]:
    U(A,B,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"U L' U' L B L' B'")
    dodeli_boje(A,B,C,D)
    # print "U L' U' L B L' B'"
  elif B[1] == A[2] and C[3] == B[2]:
    L(B,C,D)
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"L B L' B'")
    dodeli_boje(A,B,C,D)
    #print "L B L' B'"
  elif B[3] == A[2] and A[1] == B[2]:
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    L(B,C,D)
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"U' L' U L B L' B'")
    dodeli_boje(A,B,C,D)
    #print "U' L' U L B L' B'"
  elif B[6] == A[2] and D[1] == B[2]:
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"L' U' L U")
    dodeli_boje(A,B,C,D)
    #print "L' U' L U"
  elif C[1] == A[2] and A[3] == B[2]:
    R(A,C,D)
    L(B,C,D)
    L(B,C,D)
    R(A,C,D)
    R(A,C,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"R L' R' L' U' L U")
    dodeli_boje(A,B,C,D)
    #print "R L' R' L' U' L U"
  elif C[3] == A[2] and B[1] == B[2]:
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"U' L U")
    dodeli_boje(A,B,C,D)
    #print "U' L U"
  elif C[6] == A[2] and D[6] == B[2]:
    fB(A,B,C)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"B L B'")
    dodeli_boje(A,B,C,D)
    #print "B L B'"
  elif D[1] == A[2] and B[6] == B[2]:
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"B L' B'")
    dodeli_boje(A,B,C,D)
    #print "B L' B'"
  elif D[3] == A[2] and A[6] == B[2]:
    U(A,B,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"U L' U L U")
    dodeli_boje(A,B,C,D)
    #print "U L' U L U"
  elif D[6] == A[2] and C[6] == B[2]:
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"U' L' U")
    dodeli_boje(A,B,C,D)
    #print "U' L' U"

def ABC1(A,B,C):
  pom = A[0]
  A[0] = B[0]
  B[0] = C[0]
  C[0] = pom

def ABD1(A,B,D):
  pom = A[4]
  A[4] = D[0]
  D[0] = B[8]
  B[8] = pom

def ACD1(A,C,D):
  pom = A[8]
  A[8] = C[4]
  C[4] = D[8]
  D[8] = pom

def BCD1(B,C,D):
  pom = B[4]
  B[4] = D[4]
  D[4] = C[8]
  C[8] = pom

# ovo do sada mozda u pomocni fajl



def dodeli_boje(A,B,C,D):
  # mapa r -> red
  mapa = {'r':'red', 'y':'yellow', 'g':'green2', 'b':'blue'}
  # bojeX - kad se na stranu X primeni mapa
  for i in range(9):
    bojeA[i] = mapa[A[i]]
    bojeB[i] = mapa[B[i]]
    bojeC[i] = mapa[C[i]]
    bojeD[i] = mapa[D[i]]


def scena(bojeA, bojeB, bojeC, bojeD, imeB): # imeB - dugme
  root = Tk()
  root.title("Pyraminx")
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  if imeB == "pocni":
    ime = "pocni"
  elif imeB == "kraj":
    ime = "end"
    w = Label(root, text="Zavrseno!")
    w.pack(ipadx = 10, ipady = 10)
  else:
    ime = "dalje"
    w = Label(root, text=imeB)
    w.pack(ipadx = 10, ipady = 10)
  polygon = GUI(root)
  D0 = (189,174)
  D1 = (156,196)
  D2 = (222,196)
  D3 = (123,218)
  D4 = (189,218)
  D5 = (255,218)
  D6 = (90,240)
  D7 = (156,240)
  D8 = (222,240)
  D9 = (288,240)
  polygon.create_polygon([D0,D1,D2],outline='black',fill=bojeD[0], width=2) # 0
  polygon.create_polygon([D3,D1,D4],outline='black',fill=bojeD[1], width=2) # 1
  polygon.create_polygon([D4,D1,D2],outline='black',fill=bojeD[2], width=2) # 2
  polygon.create_polygon([D4,D5,D2],outline='black',fill=bojeD[3], width=2) # 3
  polygon.create_polygon([D6,D3,D7],outline='black',fill=bojeD[4], width=2) # 4
  polygon.create_polygon([D3,D7,D4],outline='black',fill=bojeD[5], width=2) # 5
  polygon.create_polygon([D4,D7,D8],outline='black',fill=bojeD[6], width=2) # 6
  polygon.create_polygon([D4,D5,D8],outline='black',fill=bojeD[7], width=2) # 7
  polygon.create_polygon([D5,D8,D9],outline='black',fill=bojeD[8], width=2) # 8
  # ---------------------------------------------------------------------------
  A0 = (189,40)
  A1 = (189,84)
  A2 = (222,106)
  A3 = (189,129)
  A4 = (222,151)
  A5 = (255,173)
  A6 = D0
  A7 = D2
  A8 = D5
  A9 = D9
  polygon.create_polygon([A0,A1,A2],outline='black',fill=bojeA[0], width=2) # 0
  polygon.create_polygon([A3,A1,A4],outline='black',fill=bojeA[1], width=2) # 1
  polygon.create_polygon([A4,A1,A2],outline='black',fill=bojeA[2], width=2) # 2
  polygon.create_polygon([A4,A5,A2],outline='black',fill=bojeA[3], width=2) # 3
  polygon.create_polygon([A6,A3,A7],outline='black',fill=bojeA[4], width=2) # 4
  polygon.create_polygon([A3,A7,A4],outline='black',fill=bojeA[5], width=2) # 5
  polygon.create_polygon([A4,A7,A8],outline='black',fill=bojeA[6], width=2) # 6
  polygon.create_polygon([A4,A5,A8],outline='black',fill=bojeA[7], width=2) # 7
  polygon.create_polygon([A5,A8,A9],outline='black',fill=bojeA[8], width=2) # 8
  # ---------------------------------------------------------------------------
  B0 = A0
  B1 = (156,106)
  B2 = A1
  B3 = (123,173)
  B4 = (156, 151)
  B5 = A3
  B6 = D6
  B7 = D3
  B8 = D1
  B9 = D0
  polygon.create_polygon([B0,B1,B2],outline='black',fill=bojeB[0], width=2) # 0
  polygon.create_polygon([B3,B1,B4],outline='black',fill=bojeB[1], width=2) # 1
  polygon.create_polygon([B4,B1,B2],outline='black',fill=bojeB[2], width=2) # 2
  polygon.create_polygon([B4,B5,B2],outline='black',fill=bojeB[3], width=2) # 3
  polygon.create_polygon([B6,B3,B7],outline='black',fill=bojeB[4], width=2) # 4
  polygon.create_polygon([B3,B7,B4],outline='black',fill=bojeB[5], width=2) # 5
  polygon.create_polygon([B4,B7,B8],outline='black',fill=bojeB[6], width=2) # 6
  polygon.create_polygon([B4,B5,B8],outline='black',fill=bojeB[7], width=2) # 7
  polygon.create_polygon([B5,B8,B9],outline='black',fill=bojeB[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  if ime != "end":
    mix_button=Button(root,text=ime,command = root.destroy)
    mix_button.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


bojeA = ['white','white','white','white','white','white','white','white','white']
bojeB = ['white','white','white','white','white','white','white','white','white']
bojeC = ['white','white','white','white','white','white','white','white','white']
bojeD = ['white','white','white','white','white','white','white','white','white']


# ---------------------------------------------------------------------------------------


# STRANA A:


def scena11(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom11():
      polygon.itemconfig(t1,fill="green2")
      bojeA[0] = "green2"
  def pom12():
      polygon.itemconfig(t1,fill="yellow")
      bojeA[0] = "yellow"
  def pom13():
      polygon.itemconfig(t1,fill="red")
      bojeA[0] = "red"
  def pom14():
      polygon.itemconfig(t1,fill="blue")
      bojeA[0] = "blue"
  def pomocna():
    root.destroy
  button=Button(root,bg="green2",activebackground = 'green2',command= lambda: [f() for f in [pom11, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom12, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom13, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom14, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()



def scena12(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom21():
      polygon.itemconfig(t2,fill="green2")
      bojeA[1] = "green2"
  def pom22():
      polygon.itemconfig(t2,fill="yellow")
      bojeA[1] = "yellow"
  def pom23():
      polygon.itemconfig(t2,fill="red")
      bojeA[1] = "red"
  def pom24():
      polygon.itemconfig(t2,fill="blue")
      bojeA[1] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom21, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom22, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom23, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom24, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


def scena13(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom31():
      polygon.itemconfig(t3,fill="green2")
      bojeA[2] = "green2"
  def pom32():
      polygon.itemconfig(t3,fill="yellow")
      bojeA[2] = "yellow"
  def pom33():
      polygon.itemconfig(t3,fill="red")
      bojeA[2] = "red"
  def pom34():
      polygon.itemconfig(t3,fill="blue")
      bojeA[2] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom31, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom32, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom33, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom34, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena14(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom41():
      polygon.itemconfig(t4,fill="green2")
      bojeA[3] = "green2"
  def pom42():
      polygon.itemconfig(t4,fill="yellow")
      bojeA[3] = "yellow"
  def pom43():
      polygon.itemconfig(t4,fill="red")
      bojeA[3] = "red"
  def pom44():
      polygon.itemconfig(t4,fill="blue")
      bojeA[3] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom41, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom42, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom43, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom44, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


def scena15(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom51():
      polygon.itemconfig(t5,fill="green2")
      bojeA[4] = "green2"
  def pom52():
      polygon.itemconfig(t5,fill="yellow")
      bojeA[4] = "yellow"
  def pom53():
      polygon.itemconfig(t5,fill="red")
      bojeA[4] = "red"
  def pom54():
      polygon.itemconfig(t5,fill="blue")
      bojeA[4] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom51, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom52, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom53, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom54, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena16(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom61():
      polygon.itemconfig(t6,fill="green2")
      bojeA[5] = "green2"
  def pom62():
      polygon.itemconfig(t6,fill="yellow")
      bojeA[5] = "yellow"
  def pom63():
      polygon.itemconfig(t6,fill="red")
      bojeA[5] = "red"
  def pom64():
      polygon.itemconfig(t6,fill="blue")
      bojeA[5] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom61, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom62, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom63, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom64, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena17(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom71():
      polygon.itemconfig(t7,fill="green2")
      bojeA[6] = "green2"
  def pom72():
      polygon.itemconfig(t7,fill="yellow")
      bojeA[6] = "yellow"
  def pom73():
      polygon.itemconfig(t7,fill="red")
      bojeA[6] = "red"
  def pom74():
      polygon.itemconfig(t7,fill="blue")
      bojeA[6] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom71, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom72, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom73, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom74, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena18(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom81():
      polygon.itemconfig(t8,fill="green2")
      bojeA[7] = "green2"
  def pom82():
      polygon.itemconfig(t8,fill="yellow")
      bojeA[7] = "yellow"
  def pom83():
      polygon.itemconfig(t8,fill="red")
      bojeA[7] = "red"
  def pom84():
      polygon.itemconfig(t8,fill="blue")
      bojeA[7] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom81, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom82, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom83, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom84, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena19(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  ind = 0
  ind1 = 0
  def pom91():
      polygon.itemconfig(t9,fill="green2")
      bojeA[8] = "green2"
      ind = 1
  def pom92():
      polygon.itemconfig(t9,fill="yellow")
      bojeA[8] = "yellow"
      ind = 1
  def pom93():
      polygon.itemconfig(t9,fill="red")
      bojeA[8] = "red"
      ind = 1
  def pom94():
      polygon.itemconfig(t9,fill="blue")
      bojeA[8] = "blue"
      ind = 1
  button=Button(root,bg="green2",activebackground = 'green2',command=pom91)#lambda: [f() for f in [pom91, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=pom92)#lambda: [f() for f in [pom92, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=pom93)#lambda: [f() for f in [pom93, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=pom94)#lambda: [f() for f in [pom94, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button=Button(root,text="dalje",command = root.destroy)
  mix_button.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()
  if niz_boja[8] == "white":
    scena19("Strana A:", niz_boja)




# ---------------------------------------------------------------------------------------


# STRANA B:


def scena21(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom11():
      polygon.itemconfig(t1,fill="green2")
      bojeB[0] = "green2"
  def pom12():
      polygon.itemconfig(t1,fill="yellow")
      bojeB[0] = "yellow"
  def pom13():
      polygon.itemconfig(t1,fill="red")
      bojeB[0] = "red"
  def pom14():
      polygon.itemconfig(t1,fill="blue")
      bojeB[0] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom11, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom12, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom13, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom14, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()



def scena22(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom21():
      polygon.itemconfig(t2,fill="green2")
      bojeB[1] = "green2"
  def pom22():
      polygon.itemconfig(t2,fill="yellow")
      bojeB[1] = "yellow"
  def pom23():
      polygon.itemconfig(t2,fill="red")
      bojeB[1] = "red"
  def pom24():
      polygon.itemconfig(t2,fill="blue")
      bojeB[1] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom21, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom22, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom23, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom24, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


def scena23(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom31():
      polygon.itemconfig(t3,fill="green2")
      bojeB[2] = "green2"
  def pom32():
      polygon.itemconfig(t3,fill="yellow")
      bojeB[2] = "yellow"
  def pom33():
      polygon.itemconfig(t3,fill="red")
      bojeB[2] = "red"
  def pom34():
      polygon.itemconfig(t3,fill="blue")
      bojeB[2] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom31, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom32, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom33, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom34, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena24(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom41():
      polygon.itemconfig(t4,fill="green2")
      bojeB[3] = "green2"
  def pom42():
      polygon.itemconfig(t4,fill="yellow")
      bojeB[3] = "yellow"
  def pom43():
      polygon.itemconfig(t4,fill="red")
      bojeB[3] = "red"
  def pom44():
      polygon.itemconfig(t4,fill="blue")
      bojeB[3] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom41, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom42, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom43, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom44, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


def scena25(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom51():
      polygon.itemconfig(t5,fill="green2")
      bojeB[4] = "green2"
  def pom52():
      polygon.itemconfig(t5,fill="yellow")
      bojeB[4] = "yellow"
  def pom53():
      polygon.itemconfig(t5,fill="red")
      bojeB[4] = "red"
  def pom54():
      polygon.itemconfig(t5,fill="blue")
      bojeB[4] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom51, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom52, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom53, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom54, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena26(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom61():
      polygon.itemconfig(t6,fill="green2")
      bojeB[5] = "green2"
  def pom62():
      polygon.itemconfig(t6,fill="yellow")
      bojeB[5] = "yellow"
  def pom63():
      polygon.itemconfig(t6,fill="red")
      bojeB[5] = "red"
  def pom64():
      polygon.itemconfig(t6,fill="blue")
      bojeB[5] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom61, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom62, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom63, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom64, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena27(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom71():
      polygon.itemconfig(t7,fill="green2")
      bojeB[6] = "green2"
  def pom72():
      polygon.itemconfig(t7,fill="yellow")
      bojeB[6] = "yellow"
  def pom73():
      polygon.itemconfig(t7,fill="red")
      bojeB[6] = "red"
  def pom74():
      polygon.itemconfig(t7,fill="blue")
      bojeB[6] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom71, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom72, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom73, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom74, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena28(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom81():
      polygon.itemconfig(t8,fill="green2")
      bojeB[7] = "green2"
  def pom82():
      polygon.itemconfig(t8,fill="yellow")
      bojeB[7] = "yellow"
  def pom83():
      polygon.itemconfig(t8,fill="red")
      bojeB[7] = "red"
  def pom84():
      polygon.itemconfig(t8,fill="blue")
      bojeB[7] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom81, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom82, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom83, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom84, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena29(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom91():
      polygon.itemconfig(t9,fill="green2")
      bojeB[8] = "green2"
  def pom92():
      polygon.itemconfig(t9,fill="yellow")
      bojeB[8] = "yellow"
  def pom93():
      polygon.itemconfig(t9,fill="red")
      bojeB[8] = "red"
  def pom94():
      polygon.itemconfig(t9,fill="blue")
      bojeB[8] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=pom91)#lambda: [f() for f in [pom91, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=pom92)#lambda: [f() for f in [pom92, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=pom93)#lambda: [f() for f in [pom93, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=pom94)#lambda: [f() for f in [pom94, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button=Button(root,text="dalje",command = root.destroy)
  mix_button.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()
  if niz_boja[8] == "white":
    scena29("Strana B:", niz_boja)


# ---------------------------------------------------------------------------------------


# STRANA C:


def scena31(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom11():
      polygon.itemconfig(t1,fill="green2")
      bojeC[0] = "green2"
  def pom12():
      polygon.itemconfig(t1,fill="yellow")
      bojeC[0] = "yellow"
  def pom13():
      polygon.itemconfig(t1,fill="red")
      bojeC[0] = "red"
  def pom14():
      polygon.itemconfig(t1,fill="blue")
      bojeC[0] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom11, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom12, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom13, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom14, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()



def scena32(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom21():
      polygon.itemconfig(t2,fill="green2")
      bojeC[1] = "green2"
  def pom22():
      polygon.itemconfig(t2,fill="yellow")
      bojeC[1] = "yellow"
  def pom23():
      polygon.itemconfig(t2,fill="red")
      bojeC[1] = "red"
  def pom24():
      polygon.itemconfig(t2,fill="blue")
      bojeC[1] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom21, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom22, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom23, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom24, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


def scena33(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom31():
      polygon.itemconfig(t3,fill="green2")
      bojeC[2] = "green2"
  def pom32():
      polygon.itemconfig(t3,fill="yellow")
      bojeC[2] = "yellow"
  def pom33():
      polygon.itemconfig(t3,fill="red")
      bojeC[2] = "red"
  def pom34():
      polygon.itemconfig(t3,fill="blue")
      bojeC[2] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom31, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom32, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom33, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom34, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena34(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom41():
      polygon.itemconfig(t4,fill="green2")
      bojeC[3] = "green2"
  def pom42():
      polygon.itemconfig(t4,fill="yellow")
      bojeC[3] = "yellow"
  def pom43():
      polygon.itemconfig(t4,fill="red")
      bojeC[3] = "red"
  def pom44():
      polygon.itemconfig(t4,fill="blue")
      bojeC[3] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom41, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom42, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom43, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom44, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


def scena35(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom51():
      polygon.itemconfig(t5,fill="green2")
      bojeC[4] = "green2"
  def pom52():
      polygon.itemconfig(t5,fill="yellow")
      bojeC[4] = "yellow"
  def pom53():
      polygon.itemconfig(t5,fill="red")
      bojeC[4] = "red"
  def pom54():
      polygon.itemconfig(t5,fill="blue")
      bojeC[4] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom51, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom52, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom53, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom54, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena36(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom61():
      polygon.itemconfig(t6,fill="green2")
      bojeC[5] = "green2"
  def pom62():
      polygon.itemconfig(t6,fill="yellow")
      bojeC[5] = "yellow"
  def pom63():
      polygon.itemconfig(t6,fill="red")
      bojeC[5] = "red"
  def pom64():
      polygon.itemconfig(t6,fill="blue")
      bojeC[5] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom61, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom62, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom63, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom64, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena37(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom71():
      polygon.itemconfig(t7,fill="green2")
      bojeC[6] = "green2"
  def pom72():
      polygon.itemconfig(t7,fill="yellow")
      bojeC[6] = "yellow"
  def pom73():
      polygon.itemconfig(t7,fill="red")
      bojeC[6] = "red"
  def pom74():
      polygon.itemconfig(t7,fill="blue")
      bojeC[6] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom71, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom72, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom73, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom74, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena38(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom81():
      polygon.itemconfig(t8,fill="green2")
      bojeC[7] = "green2"
  def pom82():
      polygon.itemconfig(t8,fill="yellow")
      bojeC[7] = "yellow"
  def pom83():
      polygon.itemconfig(t8,fill="red")
      bojeC[7] = "red"
  def pom84():
      polygon.itemconfig(t8,fill="blue")
      bojeC[7] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom81, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom82, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom83, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom84, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena39(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom91():
      polygon.itemconfig(t9,fill="green2")
      bojeC[8] = "green2"
  def pom92():
      polygon.itemconfig(t9,fill="yellow")
      bojeC[8] = "yellow"
  def pom93():
      polygon.itemconfig(t9,fill="red")
      bojeC[8] = "red"
  def pom94():
      polygon.itemconfig(t9,fill="blue")
      bojeC[8] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=pom91)#lambda: [f() for f in [pom91, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=pom92)#lambda: [f() for f in [pom92, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=pom93)#lambda: [f() for f in [pom93, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=pom94)#lambda: [f() for f in [pom94, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button=Button(root,text="dalje",command = root.destroy)
  mix_button.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()
  if niz_boja[8] == "white":
    scena39("Strana C:", niz_boja)











# ---------------------------------------------------------------------------------------


# STRANA D:


def scena41(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom11():
      polygon.itemconfig(t1,fill="green2")
      bojeD[0] = "green2"
  def pom12():
      polygon.itemconfig(t1,fill="yellow")
      bojeD[0] = "yellow"
  def pom13():
      polygon.itemconfig(t1,fill="red")
      bojeD[0] = "red"
  def pom14():
      polygon.itemconfig(t1,fill="blue")
      bojeD[0] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom11, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom12, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom13, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom14, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()



def scena42(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom21():
      polygon.itemconfig(t2,fill="green2")
      bojeD[1] = "green2"
  def pom22():
      polygon.itemconfig(t2,fill="yellow")
      bojeD[1] = "yellow"
  def pom23():
      polygon.itemconfig(t2,fill="red")
      bojeD[1] = "red"
  def pom24():
      polygon.itemconfig(t2,fill="blue")
      bojeD[1] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom21, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom22, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom23, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom24, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


def scena43(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom31():
      polygon.itemconfig(t3,fill="green2")
      bojeD[2] = "green2"
  def pom32():
      polygon.itemconfig(t3,fill="yellow")
      bojeD[2] = "yellow"
  def pom33():
      polygon.itemconfig(t3,fill="red")
      bojeD[2] = "red"
  def pom34():
      polygon.itemconfig(t3,fill="blue")
      bojeD[2] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom31, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom32, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom33, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom34, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena44(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom41():
      polygon.itemconfig(t4,fill="green2")
      bojeD[3] = "green2"
  def pom42():
      polygon.itemconfig(t4,fill="yellow")
      bojeD[3] = "yellow"
  def pom43():
      polygon.itemconfig(t4,fill="red")
      bojeD[3] = "red"
  def pom44():
      polygon.itemconfig(t4,fill="blue")
      bojeD[3] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom41, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom42, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom43, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom44, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


def scena45(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom51():
      polygon.itemconfig(t5,fill="green2")
      bojeD[4] = "green2"
  def pom52():
      polygon.itemconfig(t5,fill="yellow")
      bojeD[4] = "yellow"
  def pom53():
      polygon.itemconfig(t5,fill="red")
      bojeD[4] = "red"
  def pom54():
      polygon.itemconfig(t5,fill="blue")
      bojeD[4] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom51, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom52, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom53, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom54, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena46(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom61():
      polygon.itemconfig(t6,fill="green2")
      bojeD[5] = "green2"
  def pom62():
      polygon.itemconfig(t6,fill="yellow")
      bojeD[5] = "yellow"
  def pom63():
      polygon.itemconfig(t6,fill="red")
      bojeD[5] = "red"
  def pom64():
      polygon.itemconfig(t6,fill="blue")
      bojeD[5] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom61, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom62, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom63, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom64, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena47(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom71():
      polygon.itemconfig(t7,fill="green2")
      bojeD[6] = "green2"
  def pom72():
      polygon.itemconfig(t7,fill="yellow")
      bojeD[6] = "yellow"
  def pom73():
      polygon.itemconfig(t7,fill="red")
      bojeD[6] = "red"
  def pom74():
      polygon.itemconfig(t7,fill="blue")
      bojeD[6] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom71, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom72, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom73, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom74, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena48(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom81():
      polygon.itemconfig(t8,fill="green2")
      bojeD[7] = "green2"
  def pom82():
      polygon.itemconfig(t8,fill="yellow")
      bojeD[7] = "yellow"
  def pom83():
      polygon.itemconfig(t8,fill="red")
      bojeD[7] = "red"
  def pom84():
      polygon.itemconfig(t8,fill="blue")
      bojeD[7] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=lambda: [f() for f in [pom81, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=lambda: [f() for f in [pom82, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=lambda: [f() for f in [pom83, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=lambda: [f() for f in [pom84, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()

def scena49(strana, niz_boja):
  root = Tk()
  root.title(strana)
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  polygon = GUI(root)
  D0 = (189,114)
  D1 = (156,164)
  D2 = (222,164)
  D3 = (123,214)
  D4 = (189,214)
  D5 = (255,214)
  D6 = (90,264)
  D7 = (156,264)
  D8 = (222,264)
  D9 = (288,264)
  def pom91():
      polygon.itemconfig(t9,fill="green2")
      bojeD[8] = "green2"
  def pom92():
      polygon.itemconfig(t9,fill="yellow")
      bojeD[8] = "yellow"
  def pom93():
      polygon.itemconfig(t9,fill="red")
      bojeD[8] = "red"
  def pom94():
      polygon.itemconfig(t9,fill="blue")
      bojeD[8] = "blue"
  button=Button(root,bg="green2",activebackground = 'green2',command=pom91)#lambda: [f() for f in [pom91, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="yellow",activebackground = 'yellow',command=pom92)#lambda: [f() for f in [pom92, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="red",activebackground = 'red',command=pom93)#lambda: [f() for f in [pom93, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  button=Button(root,bg="blue",activebackground = 'blue',command=pom94)#lambda: [f() for f in [pom94, root.destroy]])
  button.pack(padx = 10, pady = 10, side=LEFT,ipadx=15,ipady=15)
  t1=polygon.create_polygon([D0,D1,D2],outline='black',fill=niz_boja[0], width=2) # 0
  t2=polygon.create_polygon([D3,D1,D4],outline='black',fill=niz_boja[1], width=2) # 1
  t3=polygon.create_polygon([D4,D1,D2],outline='black',fill=niz_boja[2], width=2) # 2
  t4=polygon.create_polygon([D4,D5,D2],outline='black',fill=niz_boja[3], width=2) # 3
  t5=polygon.create_polygon([D6,D3,D7],outline='black',fill=niz_boja[4], width=2) # 4
  t6=polygon.create_polygon([D3,D7,D4],outline='black',fill=niz_boja[5], width=2) # 5
  t7=polygon.create_polygon([D4,D7,D8],outline='black',fill=niz_boja[6], width=2) # 6
  t8=polygon.create_polygon([D4,D5,D8],outline='black',fill=niz_boja[7], width=2) # 7
  t9=polygon.create_polygon([D5,D8,D9],outline='black',fill=niz_boja[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  mix_button=Button(root,text="dalje",command = root.destroy)
  mix_button.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()
  if niz_boja[8] == "white":
    scena49("Strana D:", niz_boja)

# generisemo piramidu - unos boja od strane korisnika

scena11("Strana A:", bojeA);
scena12("Strana A:", bojeA);
scena13("Strana A:", bojeA);
scena14("Strana A:", bojeA);
scena15("Strana A:", bojeA);
scena16("Strana A:", bojeA);
scena17("Strana A:", bojeA);
scena18("Strana A:", bojeA);
scena19("Strana A:", bojeA);

scena21("Strana B:", bojeB);
scena22("Strana B:", bojeB);
scena23("Strana B:", bojeB);
scena24("Strana B:", bojeB);
scena25("Strana B:", bojeB);
scena26("Strana B:", bojeB);
scena27("Strana B:", bojeB);
scena28("Strana B:", bojeB);
scena29("Strana B:", bojeB);

scena31("Strana C:", bojeC);
scena32("Strana C:", bojeC);
scena33("Strana C:", bojeC);
scena34("Strana C:", bojeC);
scena35("Strana C:", bojeC);
scena36("Strana C:", bojeC);
scena37("Strana C:", bojeC);
scena38("Strana C:", bojeC);
scena39("Strana C:", bojeC);

scena41("Strana D:", bojeD);
scena42("Strana D:", bojeD);
scena43("Strana D:", bojeD);
scena44("Strana D:", bojeD);
scena45("Strana D:", bojeD);
scena46("Strana D:", bojeD);
scena47("Strana D:", bojeD);
scena48("Strana D:", bojeD);
scena49("Strana D:", bojeD);


map_reverse = {'red':'r','blue':'b','green2':'g','yellow':'y'} # mozda moze mapa da se iskoristi??
A = ['r','r','r','r','r','r','r','r','r']
B = ['b','b','b','b','b','b','b','b','b']
C = ['g','g','g','g','g','g','g','g','g']
D = ['y','y','y','y','y','y','y','y','y']
for i in range(9):
  A[i] = map_reverse[bojeA[i]]
  B[i] = map_reverse[bojeB[i]]
  C[i] = map_reverse[bojeC[i]]
  D[i] = map_reverse[bojeD[i]]
scena(bojeA, bojeB, bojeC, bojeD,"pocni")


# krecemo sa resavanjem:


# 0) coskovi

if A[0] != A[2]:
  if B[0] == A[2]:
    ABC1(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ABC u smeru suprotnom od smera kretanja kazaljke na satu")
    # print "okrenite cosak ABC u smeru suprotnom od smera kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)
  else:
    ABC1(A,B,C)
    ABC1(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ABC u smeru kretanja kazaljke na satu")
    # print "okrenite cosak ABC u smeru kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)

if A[4] != A[5]:
  if D[0] == A[5]:
    ABD1(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ABD u smeru suprotnom od smera kretanja kazaljke na satu")
    # print "okrenite cosak ABD u smeru suprotnom od smera kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)
  else:
    ABD1(A,B,D)
    ABD1(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ABD u smeru kretanja kazaljke na satu")
    #print "okrenite cosak ABD u smeru kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)

if A[8] != A[7]:
  if C[4] == A[7]:
    ACD1(A,C,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ACD u smeru suprotnom od smera kretanja kazaljke na satu")
    #print "okrenite cosak ACD u smeru suprotnom od smera kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)
  else:
    ACD1(A,C,D)
    ACD1(A,C,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ACD u smeru kretanja kazaljke na satu")
    #print "okrenite cosak ACD u smeru kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)

if B[4] != B[5]:
  if D[4] == B[5]:
    BCD1(B,C,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak BCD u smeru suprotnom od smera kretanja kazaljke na satu")
    #print "okrenite cosak BCD u smeru suprotnom od smera kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)
  else:
    BCD1(B,C,D)
    BCD1(B,C,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak BCD u smeru kretanja kazaljke na satu")
    #print "okrenite cosak BCD u smeru kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)


# 1) unutrasnje

if not A[2] == A[5] == A[7]:
  if A[2] == A[5]:
    if D[7] == A[0]:
      R(A,C,D)
      scena(bojeA, bojeB, bojeC, bojeD,"R")
      dodeli_boje(A,B,C,D)
      #print "R"
    elif C[5] == A[0]:
      R(A,C,D)
      R(A,C,D)
      scena(bojeA, bojeB, bojeC, bojeD,"R'")
      dodeli_boje(A,B,C,D)
      #print "R'"
    else:
      U(A,B,D)
      U(A,B,D)
      fB(A,B,C)
      scena(bojeA, bojeB, bojeC, bojeD,"U' B")
      dodeli_boje(A,B,C,D)
      #print "U' B"
      if D[5] == B[0]:
        L(B,C,D)
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L'")
        dodeli_boje(A,B,C,D)
        #print "L'"
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
	#print "B->A->C->B"
      elif C[7] == B[0]:
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L")
        dodeli_boje(A,B,C,D)
        #print "L"
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
	#print "B->A->C->B"
      else:
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
	#print "B->A->C->B"
  elif A[2] == A[7]:
    if B[7] == A[0]:
      U(A,B,D)
      scena(bojeA, bojeB, bojeC, bojeD,"U")
      dodeli_boje(A,B,C,D)
      #print "U"
    elif D[2] == A[0]:
      U(A,B,D)
      U(A,B,D)
      scena(bojeA, bojeB, bojeC, bojeD,"U'")
      dodeli_boje(A,B,C,D)
      #print "U'"
    else:
      R(A,C,D)
      fB(A,B,C)
      fB(A,B,C)
      scena(bojeA, bojeB, bojeC, bojeD,"R B'")
      dodeli_boje(A,B,C,D)
      #print "R B'"
      if B[5] == C[0]:
        L(B,C,D)
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L'")
        dodeli_boje(A,B,C,D)
        #print "L'"
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
	#print "C->A->B->C"
      elif D[5] == C[0]:
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L")
        dodeli_boje(A,B,C,D)
        #print "L"
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
	#print "C->A->B->C"
      else:
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
	#print "C->A->B->C"
  else: # A[5] != A[2] != A[7]
    brd = 0
    brl = 0
    if D[7] == A[0]:
      R(A,C,D)
      scena(bojeA, bojeB, bojeC, bojeD,"R")
      dodeli_boje(A,B,C,D)
      #print "R"
      brd = brd+1
    elif C[5] == A[0]:
      R(A,C,D)
      R(A,C,D)
      scena(bojeA, bojeB, bojeC, bojeD,"R'")
      dodeli_boje(A,B,C,D)
      #print "R'"
      brd = brd+1
    if B[7] == A[0]:
      U(A,B,D)
      scena(bojeA, bojeB, bojeC, bojeD,"U")
      dodeli_boje(A,B,C,D)
      #print "U"
      brl = brl+1
    elif D[2] == A[0]:
      U(A,B,D)
      U(A,B,D)
      scena(bojeA, bojeB, bojeC, bojeD,"U'")
      dodeli_boje(A,B,C,D)
      #print "U'"
      brl = brl+1
    if brd != 0 and brl == 0: # A[2] = A[7] != A[5]
      R(A,C,D)
      fB(A,B,C)
      fB(A,B,C)
      scena(bojeA, bojeB, bojeC, bojeD,"R B'")
      dodeli_boje(A,B,C,D)
      #print "R B'"
      if B[5] == C[0]:
        L(B,C,D)
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L'")
        dodeli_boje(A,B,C,D)
        #print "L'"
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
	#print "C->A->B->C"
      elif D[5] == C[0]:
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L")
        dodeli_boje(A,B,C,D)
        #print "L"
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
        #print "C->A->B->C"
      else:
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
        #print "C->A->B->C"
    elif brd == 0 and brl != 0: # A[2] = A[5] != A[7]
      U(A,B,D)
      U(A,B,D)
      fB(A,B,C)
      scena(bojeA, bojeB, bojeC, bojeD,"U' B")
      dodeli_boje(A,B,C,D)
      #print "U' B"
      if D[5] == B[0]:
        L(B,C,D)
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L'")
        dodeli_boje(A,B,C,D)
        #print "L'"
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
        #print "B->A->C->B"
      elif C[7] == B[0]:
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L")
        dodeli_boje(A,B,C,D)
        #print "L"
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
        #print "B->A->C->B"
      else:
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
        #print "B->A->C->B"
    #else - A[2] = A[5] = A[7]

# 2) jedna strana i donji sloj

drugi_korak(A,B,C,D) # prvi deo
BCDB(A,B,C,D) # okretanje
scena(bojeA, bojeB, bojeC, bojeD,"B->C->D->B")
dodeli_boje(A,B,C,D)
#print "B->C->D->B"
drugi_korak(A,B,C,D)# drugi deo
BCDB(A,B,C,D) # okretanje
scena(bojeA, bojeB, bojeC, bojeD,"B->C->D->B")
dodeli_boje(A,B,C,D)
#print "B->C->D->B"
drugi_korak(A,B,C,D) # treci deo


if C[7] == B[0]:
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L")
  dodeli_boje(A,B,C,D)
  #print "L"
elif D[5] == B[0]:
  L(B,C,D)
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L'")
  dodeli_boje(A,B,C,D)
  #print "L'"


# 3) zavrsna faza

BACB(A,B,C,D)
scena(bojeA, bojeB, bojeC, bojeD,"A->C->B->A")
dodeli_boje(A,B,C,D)
#print "A->C->B->A"
if A[0] == 'r':
  ABDA(A,B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"A->B->D->A")
  dodeli_boje(A,B,C,D)
  #print "A->B->D->A"
elif A[0] == 'g':
  ADBA(A,B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"A->D->B->A")
  dodeli_boje(A,B,C,D)
  #print "A->D->B->A"

if A[1] == D[0] and A[6] == D[0] and B[3] == A[0] and B[6] == A[0] and D[1] == B[0] and D[3] == B[0]:
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R U' R' U' R U' R'")
  dodeli_boje(A,B,C,D)
  #print "R U' R' U' R U' R'"
elif A[1] == B[0] and A[6] == B[0] and B[3] == D[0] and B[6] == D[0] and D[1] == A[0] and D[3] == A[0]:
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R' U R U R' U R")
  dodeli_boje(A,B,C,D)
  #print "R' U R U R' U R"
elif A[6] == D[0] and B[6] == D[0] and D[1] == B[0] and D[3] == A[0]:
  U(A,B,D)
  L(B,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"U L U' R U' R' U L'")
  dodeli_boje(A,B,C,D)
  #print "U L U' R U' R' U L'"
elif A[1] == B[0] and A[6] == D[0] and B[3] == A[0] and D[3] == A[0]:
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  U(A,B,D)
  L(B,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R' U L' U L U' R U'")
  dodeli_boje(A,B,C,D)
  #print "R' U L' U L U' R U'"
elif A[1] == B[0] and B[3] == A[0] and B[6] == D[0] and D[1] == B[0]:
  L(B,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  U(A,B,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L U' R U' R' U L' U")
  dodeli_boje(A,B,C,D)
  #print "L U' R U' R' U L' U"
elif A[1] == D[0] and A[6] == B[0] and B[3] == A[0] and D[1] == A[0]:
  L(B,C,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  L(B,C,D)
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L U R U' R' L'")
  dodeli_boje(A,B,C,D)
  #print "L U R U' R' L'"
elif A[6] == B[0] and B[3] == D[0] and B[6] == A[0] and D[1] == B[0]:
  R(A,C,D)
  R(A,C,D)
  L(B,C,D)
  L(B,C,D)
  U(A,B,D)
  U(A,B,D)
  L(B,C,D)
  U(A,B,D)
  R(A,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R' L' U' L U R")
  dodeli_boje(A,B,C,D)
  #print "R' L' U' L U R"
elif A[6] == D[0] and B[3] == D[0] and D[1] == A[0] and D[3] == B[0]:
  fB(A,B,C)
  fB(A,B,C)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  fB(A,B,C)
  scena(bojeA, bojeB, bojeC, bojeD,"B' R' U' R U B")
  dodeli_boje(A,B,C,D)
  #print "B' R' U' R U B"
elif A[1] == D[0] and A[6] == B[0] and B[6] == A[0] and D[3] == A[0]:
  L(B,C,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L R U R' U' L'")
  dodeli_boje(A,B,C,D)
  #print "L R U R' U' L'"
elif A[1] == B[0] and B[3] == D[0] and B[6] == A[0] and D[3] == B[0]:
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  U(A,B,D)
  L(B,C,D)
  R(A,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R' U' L' U L R")
  dodeli_boje(A,B,C,D)
  #print "R' U' L' U L R"
elif A[1] == D[0] and B[6] == D[0] and D[1] == A[0] and D[3] == B[0]:
  fB(A,B,C)
  fB(A,B,C)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  fB(A,B,C)
  scena(bojeA, bojeB, bojeC, bojeD,"B' U' R' U R B")
  dodeli_boje(A,B,C,D)
  #print "B' U' R' U R B"


scena(bojeA, bojeB, bojeC, bojeD,"kraj")

if A[0] == A[1] == A[2] == A[3] == A[4] == A[5] == A[6] == A[7] == A[8] and B[0] == B[1] == B[2] == B[3] == B[4] == B[5] == B[6] == B[7] == B[8] and C[0] == C[1] == C[2] == C[3] == C[4] == C[5] == C[6] == C[7] == C[8] and D[0] == D[1] == D[2] == D[3] == D[4] == D[5] == D[6] == D[7] == D[8]:
  print "\ntrue"
else:
  print "\nfalse"
