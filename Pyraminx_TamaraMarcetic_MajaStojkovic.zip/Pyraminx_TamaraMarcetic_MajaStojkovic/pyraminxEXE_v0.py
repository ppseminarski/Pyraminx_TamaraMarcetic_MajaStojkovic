#! /usr/bin/python


from Tkinter import*
import random
import sys

def center(toplevel):
    toplevel.update_idletasks()
    w = toplevel.winfo_screenwidth()
    h = toplevel.winfo_screenheight()
    size = tuple(int(_) for _ in toplevel.geometry().split('+')[0].split('x'))
    x = w/2 - size[0]/2
    y = h/2 - size[1]/2
    toplevel.geometry("%dx%d+%d+%d" % (size + (x, y)))

# osnovne funkcije

def R(A,C,D):
  pom = A[3]
  A[3] = D[3]
  D[3] = C[6]
  C[6] = pom
  pom = A[6]
  A[6] = D[6]
  D[6] = C[1]
  C[1] = pom
  pom = A[7]
  A[7] = D[7]
  D[7] = C[5]
  C[5] = pom
  pom = A[8]
  A[8] = D[8]
  D[8] = C[4]
  C[4] = pom

def L(B,C,D):
  pom = B[1]
  B[1] = C[6]
  C[6] = D[1]
  D[1] = pom
  pom = B[4]
  B[4] = C[8]
  C[8] = D[4]
  D[4] = pom
  pom = B[5]
  B[5] = C[7]
  C[7] = D[5]
  D[5] = pom
  pom = B[6]
  B[6] = C[3]
  C[3] = D[6]
  D[6] = pom

def U(A,B,D):
  pom = A[1]
  A[1] = B[6]
  B[6] = D[3]
  D[3] = pom
  pom = A[4]
  A[4] = B[8]
  B[8] = D[0]
  D[0] = pom
  pom = A[5]
  A[5] = B[7]
  B[7] = D[2]
  D[2] = pom
  pom = A[6]
  A[6] = B[3]
  B[3] = D[1]
  D[1] = pom

def fB(A,B,C):
  pom = A[0]
  A[0] = C[0]
  C[0] = B[0]
  B[0] = pom
  pom = A[1]
  A[1] = C[1]
  C[1] = B[1]
  B[1] = pom
  pom = A[2]
  A[2] = C[2]
  C[2] = B[2]
  B[2] = pom
  pom = A[3]
  A[3] = C[3]
  C[3] = B[3]
  B[3] = pom

def CABC(A,B,C,D):
  for i in range (9):
    pom = A[i]
    A[i] = C[i]
    C[i] = B[i]
    B[i] = pom
  pom = D[0]
  D[0] = D[8]
  D[8] = D[4]
  D[4] = pom
  pom = D[1]
  D[1] = D[3]
  D[3] = D[6]
  D[6] = pom
  pom = D[2]
  D[2] = D[7]
  D[7] = D[5]
  D[5] = pom

def BACB(A,B,C,D):
  for i in range(9):
    pom = A[i]
    A[i] = B[i]
    B[i] = C[i]
    C[i] = pom
  pom = D[0]
  D[0] = D[4]
  D[4] = D[8]
  D[8] = pom
  pom = D[1]
  D[1] = D[6]
  D[6] = D[3]
  D[3] = pom
  pom = D[2]
  D[2] = D[5]
  D[5] = D[7]
  D[7] = pom

def BCDB(A,B,C,D):
  pom = B[0]
  B[0] = D[0]
  D[0] = C[4]
  C[4] = pom
  pom = B[1]
  B[1] = D[1]
  D[1] = C[6]
  C[6] = pom
  pom = B[2]
  B[2] = D[2]
  D[2] = C[5]
  C[5] = pom
  pom = B[3]
  B[3] = D[3]
  D[3] = C[1]
  C[1] = pom
  pom = B[4]
  B[4] = D[4]
  D[4] = C[8]
  C[8] = pom
  pom = B[5]
  B[5] = D[5]
  D[5] = C[7]
  C[7] = pom
  pom = B[6]
  B[6] = D[6]
  D[6] = C[3]
  C[3] = pom
  pom = B[7]
  B[7] = D[7]
  D[7] = C[2]
  C[2] = pom
  pom = B[8]
  B[8] = D[8]
  D[8] = C[0]
  C[0] = pom
  pom = A[0]
  A[0] = A[4]
  A[4] = A[8]
  A[8] = pom
  pom = A[1]
  A[1] = A[6]
  A[6] = A[3]
  A[3] = pom
  pom = A[2]
  A[2] = A[5]
  A[5] = A[7]
  A[7] = pom

def ADBA(A,B,C,D):
  pom = A[0]
  A[0] = B[4]
  B[4] = D[8]
  D[8] = pom
  pom = A[1]
  A[1] = B[6]
  B[6] = D[3]
  D[3] = pom
  pom = A[2]
  A[2] = B[5]
  B[5] = D[7]
  D[7] = pom
  pom = A[3]
  A[3] = B[1]
  B[1] = D[6]
  D[6] = pom
  pom = A[4]
  A[4] = B[8]
  B[8] = D[0]
  D[0] = pom
  pom = A[5]
  A[5] = B[7]
  B[7] = D[2]
  D[2] = pom
  pom = A[6]
  A[6] = B[3]
  B[3] = D[1]
  D[1] = pom
  pom = A[7]
  A[7] = B[2]
  B[2] = D[5]
  D[5] = pom
  pom = A[8]
  A[8] = B[0]
  B[0] = D[4]
  D[4] = pom
  pom = C[0]
  C[0] = C[8]
  C[8] = C[4]
  C[4] = pom
  pom = C[1]
  C[1] = C[3]
  C[3] = C[6]
  C[6] = pom
  pom = C[2]
  C[2] = C[7]
  C[7] = C[5]
  C[5] = pom

def ABDA(A,B,C,D):
  pom = A[0]
  A[0] = D[8]
  D[8] = B[4]
  B[4] = pom
  pom = A[1]
  A[1] = D[3]
  D[3] = B[6]
  B[6] = pom
  pom = A[2]
  A[2] = D[7]
  D[7] = B[5]
  B[5] = pom
  pom = A[3]
  A[3] = D[6]
  D[6] = B[1]
  B[1] = pom
  pom = A[4]
  A[4] = D[0]
  D[0] = B[8]
  B[8] = pom
  pom = A[5]
  A[5] = D[2]
  D[2] = B[7]
  B[7] = pom
  pom = A[6]
  A[6] = D[1]
  D[1] = B[3]
  B[3] = pom
  pom = A[7]
  A[7] = D[5]
  D[5] = B[2]
  B[2] = pom
  pom = A[8]
  A[8] = D[4]
  D[4] = B[0]
  B[0] = pom
  pom = C[0]
  C[0] = C[4]
  C[4] = C[8]
  C[8] = pom
  pom = C[1]
  C[1] = C[6]
  C[6] = C[3]
  C[3] = pom
  pom = C[2]
  C[2] = C[5]
  C[5] = C[7]
  C[7] = pom

def drugi_korak(A,B,C,D):
  if A[3] == A[2] and C[1] == B[2]:
    R(A,C,D)
    L(B,C,D)
    R(A,C,D)
    R(A,C,D)
    L(B,C,D)
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"R L R' L B L' B'")
    dodeli_boje(A,B,C,D)
    #print "R L R' L B L' B'"
  elif A[6] == A[2] and D[3] == B[2]:
    U(A,B,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"U L' U' L B L' B'")
    dodeli_boje(A,B,C,D)
    # print "U L' U' L B L' B'"
  elif B[1] == A[2] and C[3] == B[2]:
    L(B,C,D)
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"L B L' B'")
    dodeli_boje(A,B,C,D)
    #print "L B L' B'"
  elif B[3] == A[2] and A[1] == B[2]:
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    L(B,C,D)
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"U' L' U L B L' B'")
    dodeli_boje(A,B,C,D)
    #print "U' L' U L B L' B'"
  elif B[6] == A[2] and D[1] == B[2]:
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"L' U' L U")
    dodeli_boje(A,B,C,D)
    #print "L' U' L U"
  elif C[1] == A[2] and A[3] == B[2]:
    R(A,C,D)
    L(B,C,D)
    L(B,C,D)
    R(A,C,D)
    R(A,C,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"R L' R' L' U' L U")
    dodeli_boje(A,B,C,D)
    #print "R L' R' L' U' L U"
  elif C[3] == A[2] and B[1] == B[2]:
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"U' L U")
    dodeli_boje(A,B,C,D)
    #print "U' L U"
  elif C[6] == A[2] and D[6] == B[2]:
    fB(A,B,C)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"B L B'")
    dodeli_boje(A,B,C,D)
    #print "B L B'"
  elif D[1] == A[2] and B[6] == B[2]:
    fB(A,B,C)
    L(B,C,D)
    L(B,C,D)
    fB(A,B,C)
    fB(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"B L' B'")
    dodeli_boje(A,B,C,D)
    #print "B L' B'"
  elif D[3] == A[2] and A[6] == B[2]:
    U(A,B,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"U L' U L U")
    dodeli_boje(A,B,C,D)
    #print "U L' U L U"
  elif D[6] == A[2] and C[6] == B[2]:
    U(A,B,D)
    U(A,B,D)
    L(B,C,D)
    L(B,C,D)
    U(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"U' L' U")
    dodeli_boje(A,B,C,D)
    #print "U' L' U"

def ABC1(A,B,C):
  pom = A[0]
  A[0] = B[0]
  B[0] = C[0]
  C[0] = pom

def ABD1(A,B,D):
  pom = A[4]
  A[4] = D[0]
  D[0] = B[8]
  B[8] = pom

def ACD1(A,C,D):
  pom = A[8]
  A[8] = C[4]
  C[4] = D[8]
  D[8] = pom

def BCD1(B,C,D):
  pom = B[4]
  B[4] = D[4]
  D[4] = C[8]
  C[8] = pom

# ovo do sada mozda u pomocni fajl



def dodeli_boje(A,B,C,D):
  # mapa r -> red
  mapa = {'r':'red', 'y':'yellow', 'g':'green2', 'b':'blue'}
  # bojeX - kad se na stranu X primeni mapa
  for i in range(9):
    bojeA[i] = mapa[A[i]]
    bojeB[i] = mapa[B[i]]
    bojeC[i] = mapa[C[i]]
    bojeD[i] = mapa[D[i]]


def scena(bojeA, bojeB, bojeC, bojeD, imeB): # imeB - dugme
  root = Tk()
  root.title("Pyraminx")
  class GUI(Canvas):
    '''inherits Canvas class (all Canvas methodes, attributes will be accessible)
       You can add your customized methods here.
    '''
  def __init__(self,master,*args,**kwargs):
    Canvas.__init__(self, master=master, *args, **kwargs)
# treca opcija posle text je da se doda command=funkcija koju sami definisemo,command radi kada kliknemo na dugme
  if imeB == "pocni":
    ime = "pocni"
  elif imeB == "random":
    ime = "random"
  elif imeB == "kraj":
    ime = "end"
    w = Label(root, text="Zavrseno!")
    w.pack(ipadx = 10, ipady = 10)
  else:
    ime = "dalje"
    w = Label(root, text=imeB)
    w.pack(ipadx = 10, ipady = 10)
  polygon = GUI(root)
  D0 = (189,174)
  D1 = (156,196)
  D2 = (222,196)
  D3 = (123,218)
  D4 = (189,218)
  D5 = (255,218)
  D6 = (90,240)
  D7 = (156,240)
  D8 = (222,240)
  D9 = (288,240)
  polygon.create_polygon([D0,D1,D2],outline='black',fill=bojeD[0], width=2) # 0
  polygon.create_polygon([D3,D1,D4],outline='black',fill=bojeD[1], width=2) # 1
  polygon.create_polygon([D4,D1,D2],outline='black',fill=bojeD[2], width=2) # 2
  polygon.create_polygon([D4,D5,D2],outline='black',fill=bojeD[3], width=2) # 3
  polygon.create_polygon([D6,D3,D7],outline='black',fill=bojeD[4], width=2) # 4
  polygon.create_polygon([D3,D7,D4],outline='black',fill=bojeD[5], width=2) # 5
  polygon.create_polygon([D4,D7,D8],outline='black',fill=bojeD[6], width=2) # 6
  polygon.create_polygon([D4,D5,D8],outline='black',fill=bojeD[7], width=2) # 7
  polygon.create_polygon([D5,D8,D9],outline='black',fill=bojeD[8], width=2) # 8
  # ---------------------------------------------------------------------------
  A0 = (189,40)
  A1 = (189,84)
  A2 = (222,106)
  A3 = (189,129)
  A4 = (222,151)
  A5 = (255,173)
  A6 = D0
  A7 = D2
  A8 = D5
  A9 = D9
  polygon.create_polygon([A0,A1,A2],outline='black',fill=bojeA[0], width=2) # 0
  polygon.create_polygon([A3,A1,A4],outline='black',fill=bojeA[1], width=2) # 1
  polygon.create_polygon([A4,A1,A2],outline='black',fill=bojeA[2], width=2) # 2
  polygon.create_polygon([A4,A5,A2],outline='black',fill=bojeA[3], width=2) # 3
  polygon.create_polygon([A6,A3,A7],outline='black',fill=bojeA[4], width=2) # 4
  polygon.create_polygon([A3,A7,A4],outline='black',fill=bojeA[5], width=2) # 5
  polygon.create_polygon([A4,A7,A8],outline='black',fill=bojeA[6], width=2) # 6
  polygon.create_polygon([A4,A5,A8],outline='black',fill=bojeA[7], width=2) # 7
  polygon.create_polygon([A5,A8,A9],outline='black',fill=bojeA[8], width=2) # 8
  # ---------------------------------------------------------------------------
  B0 = A0
  B1 = (156,106)
  B2 = A1
  B3 = (123,173)
  B4 = (156, 151)
  B5 = A3
  B6 = D6
  B7 = D3
  B8 = D1
  B9 = D0
  polygon.create_polygon([B0,B1,B2],outline='black',fill=bojeB[0], width=2) # 0
  polygon.create_polygon([B3,B1,B4],outline='black',fill=bojeB[1], width=2) # 1
  polygon.create_polygon([B4,B1,B2],outline='black',fill=bojeB[2], width=2) # 2
  polygon.create_polygon([B4,B5,B2],outline='black',fill=bojeB[3], width=2) # 3
  polygon.create_polygon([B6,B3,B7],outline='black',fill=bojeB[4], width=2) # 4
  polygon.create_polygon([B3,B7,B4],outline='black',fill=bojeB[5], width=2) # 5
  polygon.create_polygon([B4,B7,B8],outline='black',fill=bojeB[6], width=2) # 6
  polygon.create_polygon([B4,B5,B8],outline='black',fill=bojeB[7], width=2) # 7
  polygon.create_polygon([B5,B8,B9],outline='black',fill=bojeB[8], width=2) # 8
  polygon.pack(padx = 10, pady = 10)
  if ime != "end":
    mix_button=Button(root,text=ime,command = root.destroy)
    mix_button.pack(padx = 10, pady = 10)
  mix_button1=Button(root,text="izlaz",command = sys.exit)
  mix_button1.pack(padx = 10, pady = 10,side = RIGHT)
  root.minsize(width = 480, height = 450)
  center(root)
  root.mainloop()


bojeA = ['blue','blue','blue','blue','blue','blue','blue','blue','blue']
bojeB = ['red','red','red','red','red','red','red','red','red']
bojeC = ['yellow','yellow','yellow','yellow','yellow','yellow','yellow','yellow','yellow']
bojeD = ['green2','green2','green2','green2','green2','green2','green2','green2','green2']



"""


# unos podataka od strane korisnika

print "Unesite elemente strane A: "
x = raw_input()
A = x.split(" ")
if len(A) != 9:
  izlaz("Unos nije ispravan!")

print "Unesite elemente strane B: "
x = raw_input()
B = x.split(" ")
if len(B) != 9:
  izlaz("Unos nije ispravan!")

print "Unesite elemente strane C: "
x = raw_input()
C = x.split(" ")
if len(C) != 9:
  izlaz("Unos nije ispravan!")

print "Unesite elemente strane D: "
x = raw_input()
D = x.split(" ")
if len(D) != 9:
  izlaz("Unos nije ispravan!")


"""

# nasumicno generisemo boje:
scena(bojeA,bojeB,bojeC,bojeD,"random")
A = ['b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b']
B = ['r', 'r', 'r', 'r', 'r', 'r', 'r', 'r', 'r']
C = ['y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y']
D = ['g', 'g', 'g', 'g', 'g', 'g', 'g', 'g', 'g']
pom = [random.randint(0,7) for k in range(30)] # 30 nasumicnih poteza
# 0	1	2	3	4	5	6	7
# R	L	U	B	R'	L'	U'	B'
for i in range(30):
  if pom[i] == 0:
    R(A,C,D)
  elif pom[i] == 1:
    L(B,C,D)
  elif pom[i] == 2:
    U(A,B,D)
  elif pom[i] == 3:
    fB(A,B,C)
  elif pom[i] == 4:
    R(A,C,D)
    R(A,C,D)
  elif pom[i] == 5:
    L(B,C,D)
    L(B,C,D)
  elif pom[i] == 6:
    U(A,B,D)
    U(A,B,D)
  elif pom[i] == 7:
    fB(A,B,C)
    fB(A,B,C)
cosABC = random.randint(0,2)
cosABD = random.randint(0,2)
cosACD = random.randint(0,2)
cosBCD = random.randint(0,2)
if cosABC == 1:
  ABC1(A,B,C)
elif cosABC == 2:
  ABC1(A,B,C)
  ABC1(A,B,C)
if cosABD == 1:
  ABD1(A,B,D)
elif cosABD == 2:
  ABD1(A,B,D)
  ABD1(A,B,D)
if cosACD == 1:
  ACD1(A,C,D)
elif cosACD == 2:
  ACD1(A,C,D)
  ACD1(A,C,D)
if cosBCD == 1:
  BCD1(B,C,D)
elif cosBCD == 2:
  BCD1(B,C,D)
  BCD1(B,C,D)



dodeli_boje(A,B,C,D)
scena(bojeA, bojeB, bojeC, bojeD,"pocni")


# krecemo sa resavanjem:


# 0) coskovi

if A[0] != A[2]:
  if B[0] == A[2]:
    ABC1(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ABC u smeru suprotnom od smera kretanja kazaljke na satu")
    # print "okrenite cosak ABC u smeru suprotnom od smera kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)
  else:
    ABC1(A,B,C)
    ABC1(A,B,C)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ABC u smeru kretanja kazaljke na satu")
    # print "okrenite cosak ABC u smeru kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)

if A[4] != A[5]:
  if D[0] == A[5]:
    ABD1(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ABD u smeru suprotnom od smera kretanja kazaljke na satu")
    # print "okrenite cosak ABD u smeru suprotnom od smera kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)
  else:
    ABD1(A,B,D)
    ABD1(A,B,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ABD u smeru kretanja kazaljke na satu")
    #print "okrenite cosak ABD u smeru kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)

if A[8] != A[7]:
  if C[4] == A[7]:
    ACD1(A,C,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ACD u smeru suprotnom od smera kretanja kazaljke na satu")
    #print "okrenite cosak ACD u smeru suprotnom od smera kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)
  else:
    ACD1(A,C,D)
    ACD1(A,C,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak ACD u smeru kretanja kazaljke na satu")
    #print "okrenite cosak ACD u smeru kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)

if B[4] != B[5]:
  if D[4] == B[5]:
    BCD1(B,C,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak BCD u smeru suprotnom od smera kretanja kazaljke na satu")
    #print "okrenite cosak BCD u smeru suprotnom od smera kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)
  else:
    BCD1(B,C,D)
    BCD1(B,C,D)
    scena(bojeA, bojeB, bojeC, bojeD,"okrenite cosak BCD u smeru kretanja kazaljke na satu")
    #print "okrenite cosak BCD u smeru kretanja kazaljke na satu"
    dodeli_boje(A,B,C,D)


# 1) unutrasnje

if not A[2] == A[5] == A[7]:
  if A[2] == A[5]:
    if D[7] == A[0]:
      R(A,C,D)
      scena(bojeA, bojeB, bojeC, bojeD,"R")
      dodeli_boje(A,B,C,D)
      #print "R"
    elif C[5] == A[0]:
      R(A,C,D)
      R(A,C,D)
      scena(bojeA, bojeB, bojeC, bojeD,"R'")
      dodeli_boje(A,B,C,D)
      #print "R'"
    else:
      U(A,B,D)
      U(A,B,D)
      fB(A,B,C)
      scena(bojeA, bojeB, bojeC, bojeD,"U' B")
      dodeli_boje(A,B,C,D)
      #print "U' B"
      if D[5] == B[0]:
        L(B,C,D)
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L'")
        dodeli_boje(A,B,C,D)
        #print "L'"
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
	#print "B->A->C->B"
      elif C[7] == B[0]:
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L")
        dodeli_boje(A,B,C,D)
        #print "L"
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
	#print "B->A->C->B"
      else:
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
	#print "B->A->C->B"
  elif A[2] == A[7]:
    if B[7] == A[0]:
      U(A,B,D)
      scena(bojeA, bojeB, bojeC, bojeD,"U")
      dodeli_boje(A,B,C,D)
      #print "U"
    elif D[2] == A[0]:
      U(A,B,D)
      U(A,B,D)
      scena(bojeA, bojeB, bojeC, bojeD,"U'")
      dodeli_boje(A,B,C,D)
      #print "U'"
    else:
      R(A,C,D)
      fB(A,B,C)
      fB(A,B,C)
      scena(bojeA, bojeB, bojeC, bojeD,"R B'")
      dodeli_boje(A,B,C,D)
      #print "R B'"
      if B[5] == C[0]:
        L(B,C,D)
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L'")
        dodeli_boje(A,B,C,D)
        #print "L'"
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
	#print "C->A->B->C"
      elif D[5] == C[0]:
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L")
        dodeli_boje(A,B,C,D)
        #print "L"
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
	#print "C->A->B->C"
      else:
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
	#print "C->A->B->C"
  else: # A[5] != A[2] != A[7]
    brd = 0
    brl = 0
    if D[7] == A[0]:
      R(A,C,D)
      scena(bojeA, bojeB, bojeC, bojeD,"R")
      dodeli_boje(A,B,C,D)
      #print "R"
      brd = brd+1
    elif C[5] == A[0]:
      R(A,C,D)
      R(A,C,D)
      scena(bojeA, bojeB, bojeC, bojeD,"R'")
      dodeli_boje(A,B,C,D)
      #print "R'"
      brd = brd+1
    if B[7] == A[0]:
      U(A,B,D)
      scena(bojeA, bojeB, bojeC, bojeD,"U")
      dodeli_boje(A,B,C,D)
      #print "U"
      brl = brl+1
    elif D[2] == A[0]:
      U(A,B,D)
      U(A,B,D)
      scena(bojeA, bojeB, bojeC, bojeD,"U'")
      dodeli_boje(A,B,C,D)
      #print "U'"
      brl = brl+1
    if brd != 0 and brl == 0: # A[2] = A[7] != A[5]
      R(A,C,D)
      fB(A,B,C)
      fB(A,B,C)
      scena(bojeA, bojeB, bojeC, bojeD,"R B'")
      dodeli_boje(A,B,C,D)
      #print "R B'"
      if B[5] == C[0]:
        L(B,C,D)
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L'")
        dodeli_boje(A,B,C,D)
        #print "L'"
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
	#print "C->A->B->C"
      elif D[5] == C[0]:
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L")
        dodeli_boje(A,B,C,D)
        #print "L"
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
        #print "C->A->B->C"
      else:
        CABC(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"C->A->B->C")
        dodeli_boje(A,B,C,D)
        #print "C->A->B->C"
    elif brd == 0 and brl != 0: # A[2] = A[5] != A[7]
      U(A,B,D)
      U(A,B,D)
      fB(A,B,C)
      scena(bojeA, bojeB, bojeC, bojeD,"U' B")
      dodeli_boje(A,B,C,D)
      #print "U' B"
      if D[5] == B[0]:
        L(B,C,D)
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L'")
        dodeli_boje(A,B,C,D)
        #print "L'"
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
        #print "B->A->C->B"
      elif C[7] == B[0]:
        L(B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"L")
        dodeli_boje(A,B,C,D)
        #print "L"
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
        #print "B->A->C->B"
      else:
        BACB(A,B,C,D)
        scena(bojeA, bojeB, bojeC, bojeD,"B->A->C->B")
        dodeli_boje(A,B,C,D)
        #print "B->A->C->B"
    #else - A[2] = A[5] = A[7]

# 2) jedna strana i donji sloj

drugi_korak(A,B,C,D) # prvi deo
BCDB(A,B,C,D) # okretanje
scena(bojeA, bojeB, bojeC, bojeD,"B->C->D->B")
dodeli_boje(A,B,C,D)
#print "B->C->D->B"
drugi_korak(A,B,C,D)# drugi deo
BCDB(A,B,C,D) # okretanje
scena(bojeA, bojeB, bojeC, bojeD,"B->C->D->B")
dodeli_boje(A,B,C,D)
#print "B->C->D->B"
drugi_korak(A,B,C,D) # treci deo


if C[7] == B[0]:
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L")
  dodeli_boje(A,B,C,D)
  #print "L"
elif D[5] == B[0]:
  L(B,C,D)
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L'")
  dodeli_boje(A,B,C,D)
  #print "L'"


# 3) zavrsna faza

BACB(A,B,C,D)
scena(bojeA, bojeB, bojeC, bojeD,"A->C->B->A")
dodeli_boje(A,B,C,D)
#print "A->C->B->A"
if A[0] == 'r':
  ABDA(A,B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"A->B->D->A")
  dodeli_boje(A,B,C,D)
  #print "A->B->D->A"
elif A[0] == 'g':
  ADBA(A,B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"A->D->B->A")
  dodeli_boje(A,B,C,D)
  #print "A->D->B->A"

if A[1] == D[0] and A[6] == D[0] and B[3] == A[0] and B[6] == A[0] and D[1] == B[0] and D[3] == B[0]:
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R U' R' U' R U' R'")
  dodeli_boje(A,B,C,D)
  #print "R U' R' U' R U' R'"
elif A[1] == B[0] and A[6] == B[0] and B[3] == D[0] and B[6] == D[0] and D[1] == A[0] and D[3] == A[0]:
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R' U R U R' U R")
  dodeli_boje(A,B,C,D)
  #print "R' U R U R' U R"
elif A[6] == D[0] and B[6] == D[0] and D[1] == B[0] and D[3] == A[0]:
  U(A,B,D)
  L(B,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"U L U' R U' R' U L'")
  dodeli_boje(A,B,C,D)
  #print "U L U' R U' R' U L'"
elif A[1] == B[0] and A[6] == D[0] and B[3] == A[0] and D[3] == A[0]:
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  U(A,B,D)
  L(B,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R' U L' U L U' R U'")
  dodeli_boje(A,B,C,D)
  #print "R' U L' U L U' R U'"
elif A[1] == B[0] and B[3] == A[0] and B[6] == D[0] and D[1] == B[0]:
  L(B,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  U(A,B,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L U' R U' R' U L' U")
  dodeli_boje(A,B,C,D)
  #print "L U' R U' R' U L' U"
elif A[1] == D[0] and A[6] == B[0] and B[3] == A[0] and D[1] == A[0]:
  L(B,C,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  L(B,C,D)
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L U R U' R' L'")
  dodeli_boje(A,B,C,D)
  #print "L U R U' R' L'"
elif A[6] == B[0] and B[3] == D[0] and B[6] == A[0] and D[1] == B[0]:
  R(A,C,D)
  R(A,C,D)
  L(B,C,D)
  L(B,C,D)
  U(A,B,D)
  U(A,B,D)
  L(B,C,D)
  U(A,B,D)
  R(A,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R' L' U' L U R")
  dodeli_boje(A,B,C,D)
  #print "R' L' U' L U R"
elif A[6] == D[0] and B[3] == D[0] and D[1] == A[0] and D[3] == B[0]:
  fB(A,B,C)
  fB(A,B,C)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  U(A,B,D)
  fB(A,B,C)
  scena(bojeA, bojeB, bojeC, bojeD,"B' R' U' R U B")
  dodeli_boje(A,B,C,D)
  #print "B' R' U' R U B"
elif A[1] == D[0] and A[6] == B[0] and B[6] == A[0] and D[3] == A[0]:
  L(B,C,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"L R U R' U' L'")
  dodeli_boje(A,B,C,D)
  #print "L R U R' U' L'"
elif A[1] == B[0] and B[3] == D[0] and B[6] == A[0] and D[3] == B[0]:
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  U(A,B,D)
  L(B,C,D)
  L(B,C,D)
  U(A,B,D)
  L(B,C,D)
  R(A,C,D)
  scena(bojeA, bojeB, bojeC, bojeD,"R' U' L' U L R")
  dodeli_boje(A,B,C,D)
  #print "R' U' L' U L R"
elif A[1] == D[0] and B[6] == D[0] and D[1] == A[0] and D[3] == B[0]:
  fB(A,B,C)
  fB(A,B,C)
  U(A,B,D)
  U(A,B,D)
  R(A,C,D)
  R(A,C,D)
  U(A,B,D)
  R(A,C,D)
  fB(A,B,C)
  scena(bojeA, bojeB, bojeC, bojeD,"B' U' R' U R B")
  dodeli_boje(A,B,C,D)
  #print "B' U' R' U R B"



scena(bojeA, bojeB, bojeC, bojeD,"kraj")

if A[0] == A[1] == A[2] == A[3] == A[4] == A[5] == A[6] == A[7] == A[8] and B[0] == B[1] == B[2] == B[3] == B[4] == B[5] == B[6] == B[7] == B[8] and C[0] == C[1] == C[2] == C[3] == C[4] == C[5] == C[6] == C[7] == C[8] and D[0] == D[1] == D[2] == D[3] == D[4] == D[5] == D[6] == D[7] == D[8]:
  print "\ntrue"
else:
  print "\nfalse"
